
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBRHn2XuNngv1c0QHYmRsc4hf_rthCQvx8',
    appId: '1:973317817673:web:4cb4862e0d0d1dcb2a4698',
    messagingSenderId: '973317817673',
    projectId: 'worknest-94c2c',
    authDomain: 'worknest-94c2c.firebaseapp.com',
    storageBucket: 'worknest-94c2c.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyB-Jhd6nkmxGMFJUIgpGm5jFwKKlH7KwaM',
    appId: '1:973317817673:android:239ca9f92e8837f12a4698',
    messagingSenderId: '973317817673',
    projectId: 'worknest-94c2c',
    storageBucket: 'worknest-94c2c.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyC--ckSz-PtqK86RTRktBqe3EbNxgtIZNA',
    appId: '1:973317817673:ios:0ff986551b0435cd2a4698',
    messagingSenderId: '973317817673',
    projectId: 'worknest-94c2c',
    storageBucket: 'worknest-94c2c.firebasestorage.app',
    iosBundleId: 'com.example.workNest',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyC--ckSz-PtqK86RTRktBqe3EbNxgtIZNA',
    appId: '1:973317817673:ios:0ff986551b0435cd2a4698',
    messagingSenderId: '973317817673',
    projectId: 'worknest-94c2c',
    storageBucket: 'worknest-94c2c.firebasestorage.app',
    iosBundleId: 'com.example.workNest',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyBRHn2XuNngv1c0QHYmRsc4hf_rthCQvx8',
    appId: '1:973317817673:web:4d99f7e6b070e9f92a4698',
    messagingSenderId: '973317817673',
    projectId: 'worknest-94c2c',
    authDomain: 'worknest-94c2c.firebaseapp.com',
    storageBucket: 'worknest-94c2c.firebasestorage.app',
  );
}
